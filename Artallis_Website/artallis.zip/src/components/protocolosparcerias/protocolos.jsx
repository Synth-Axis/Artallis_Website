const protocolos = [
  {
    id: 1,
    text: "Agrupamento de escolas 4 de outubro",
    size: "small",
  },
  {
    id: 2,
    text: "Agrupamento de escolas da Bobadela",
    size: "small",
  },
  {
    id: 3,
    text: "Agrupamento de escolas da Portela e Moscavide",
    size: "small",
  },
  {
    id: 4,
    text: "Agrupamento de escolas de Camarate",
    size: "small",
  },
  {
    id: 5,
    text: "Agrupamento de escolas de Santa Iria da Azóia",
    size: "small",
  },
  {
    id: 6,
    text: "Agrupamento de escolas de Santa Maria dos Olivais",
    size: "large",
  },
  {
    id: 7,
    text: "Agrupamento de escolas do Catujal",
    size: "small",
  },
  {
    id: 8,
    text: "Agrupamento de escolas Eduardo Gageiro",
    size: "small",
  },
  {
    id: 9,
    text: "Agrupamento de escolas General Humberto Delgado",
    size: "small",
  },
  {
    id: 10,
    text: "Agrupamento de escolas João Villaret",
    size: "small",
  },
  {
    id: 11,
    text: "Agrupamento de escolas José Afonso",
    size: "medium",
  },
  {
    id: 12,
    text: "Agrupamento de escolas Luís Sttau Monteiro",
    size: "large bg-cyan",
  },
  {
    id: 13,
    text: "Agrupamento de escolas Maria Keil",
    size: "small",
  },
  {
    id: 14,
    text: "Agrupamento de escolas Maria Veleda",
    size: "small",
  },
  {
    id: 15,
    text: "Agrupamento de escolas São João da Talha",
    size: "small",
  },
  {
    id: 16,
    text: "Associação “O Saltarico”",
    size: "small",
  },
  {
    id: 17,
    text: "Associação Cantinho das Crianças",
    size: "small",
  },
  {
    id: 18,
    text: "Associação Dr. João dos Santos",
    size: "small",
  },
  {
    id: 19,
    text: "Agrupamento de escolas de Santa Iria da Azóia",
    size: "small",
  },
  {
    id: 20,
    text: "Agrupamento de escolas de Santa Maria dos Olivais",
    size: "large",
  },
  {
    id: 21,
    text: "Agrupamento de escolas do Catujal",
    size: "small",
  },
  {
    id: 22,
    text: "Agrupamento de escolas 4 de outubro",
    size: "small",
  },
  {
    id: 23,
    text: "Agrupamento de escolas da Bobadela",
    size: "small",
  },
  {
    id: 24,
    text: "Agrupamento de escolas da Portela e Moscavide",
    size: "small",
  },
  {
    id: 25,
    text: "Agrupamento de escolas de Camarate",
    size: "small",
  },
];

export default protocolos;
